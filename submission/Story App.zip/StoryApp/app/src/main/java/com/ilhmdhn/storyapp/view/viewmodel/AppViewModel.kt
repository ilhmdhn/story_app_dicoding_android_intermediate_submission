package com.ilhmdhn.storyapp.view.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.ilhmdhn.storyapp.remote.AppRepository
import com.ilhmdhn.storyapp.remote.response.BaseResponse
import com.ilhmdhn.storyapp.remote.response.DetailResponse
import com.ilhmdhn.storyapp.remote.response.LoginResponse
import com.ilhmdhn.storyapp.remote.response.StoryResponse
import okhttp3.MultipartBody
import okhttp3.RequestBody

class AppViewModel: ViewModel() {
    val appRepository = AppRepository()

    fun postLogin(email: String, password: String):LiveData<LoginResponse>{
        return appRepository.postLogin(email, password)
    }

    fun postRegister(name: String, email: String, password: String):LiveData<BaseResponse>{
        return appRepository.postRegister(name, email, password);
    }

    fun getStory(auth: String): LiveData<StoryResponse>{
        return appRepository.getStory(auth)
    }

    fun postStory(auth: String, file: MultipartBody.Part, description: RequestBody):LiveData<BaseResponse>{
        return appRepository.postStory(auth, file, description)
    }

    fun getDetailStory(auth: String, id: String): LiveData<DetailResponse>{
        return appRepository.getDetailStory(auth, id)
    }
}