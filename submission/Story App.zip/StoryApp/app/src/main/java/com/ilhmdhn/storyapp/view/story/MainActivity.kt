package com.ilhmdhn.storyapp.view.story

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.ilhmdhn.storyapp.R
import com.ilhmdhn.storyapp.databinding.ActivityMainBinding
import com.ilhmdhn.storyapp.model.Loading
import com.ilhmdhn.storyapp.model.user.UserPreference
import com.ilhmdhn.storyapp.view.login.LoginActivity
import com.ilhmdhn.storyapp.view.viewmodel.AppViewModel
import org.greenrobot.eventbus.EventBus
import org.greenrobot.eventbus.Subscribe
import org.greenrobot.eventbus.ThreadMode

class MainActivity : AppCompatActivity() {

    private lateinit var appViewModel: AppViewModel
    private lateinit var binding: ActivityMainBinding
    private lateinit var userPreference: UserPreference
    private val storyAdapter = StoryAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        appViewModel = ViewModelProvider(this).get(AppViewModel::class.java)
        userPreference = UserPreference(this)

        binding.fabAddStory.setOnClickListener {
            startActivity(Intent(this, AddStoryActivity::class.java))
        }

        getStoryData()

        with(binding.rvStory){
            layoutManager = LinearLayoutManager(this@MainActivity)
            setHasFixedSize(true)
            adapter = storyAdapter
        }
    }

    private fun getStoryData(){
        appViewModel.getStory(userPreference.getUser().token.toString()).observe(this, { dataStory->
            if (dataStory.error){
                Toast.makeText(this, dataStory.message, Toast.LENGTH_SHORT).show()
            }else{
                storyAdapter.setData(dataStory.listStory)
            }
        })
    }

    @Subscribe(threadMode = ThreadMode.MAIN)
    fun loading(loading: Loading){
        if (loading.isLoading){
            binding.pbLoading.visibility = View.VISIBLE
        }else{
            binding.pbLoading.visibility = View.GONE
        }
    }

    override fun onStart() {
        super.onStart()
        EventBus.getDefault().register(this)
    }

    override fun onStop() {
        super.onStop()
        EventBus.getDefault().unregister(this)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_logout -> {
                logout()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun logout() {
        userPreference.delUser()
        finish()
        startActivity(Intent(this, LoginActivity::class.java))
    }
}