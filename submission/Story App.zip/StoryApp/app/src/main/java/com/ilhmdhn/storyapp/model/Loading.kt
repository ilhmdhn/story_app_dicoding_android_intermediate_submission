package com.ilhmdhn.storyapp.model

data class Loading(
    var isLoading: Boolean
)