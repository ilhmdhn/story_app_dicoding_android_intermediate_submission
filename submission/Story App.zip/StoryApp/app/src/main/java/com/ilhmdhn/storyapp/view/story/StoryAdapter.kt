package com.ilhmdhn.storyapp.view.story

import android.annotation.SuppressLint
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ilhmdhn.storyapp.R
import com.ilhmdhn.storyapp.databinding.ListStoryBinding
import com.ilhmdhn.storyapp.remote.response.ListStoryItem

class StoryAdapter: RecyclerView.Adapter<StoryAdapter.ListViewHolder>() {

    private var listData = ArrayList<ListStoryItem>()

    @SuppressLint("NotifyDataSetChanged")
    fun setData(newListData: List<ListStoryItem>?){
        if (newListData != null){
            listData.clear()
            listData.addAll(newListData)
            notifyDataSetChanged()
        }
    }

    inner class ListViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        private val binding = ListStoryBinding.bind(itemView)
        fun bind(data: ListStoryItem){
            with(binding){
                Glide.with(itemView.context)
                    .load(data.photoUrl)
                    .into(binding.ivItemPhoto)
                tvItemName.text = data.name

                itemView.setOnClickListener {
                    val intent = Intent(itemView.context, DetailStoryActivity::class.java)
                    intent.putExtra(DetailStoryActivity.DATA_DETAIL, data)
                    itemView.context.startActivity(intent)
                }
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListViewHolder {
        return ListViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.list_story, parent, false))
    }

    override fun onBindViewHolder(holder: ListViewHolder, position: Int) {
        val data = listData[position]
        holder.bind(data)
    }

    override fun getItemCount(): Int {
        return listData.size
    }
}